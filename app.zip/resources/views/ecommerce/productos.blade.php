@extends('layouts.ecommerce')
@section('content')
    @livewire('ecommerce.index-product')
@endsection
