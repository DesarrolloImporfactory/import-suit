@extends('layouts.app')

@section('content')
    <div class="container py-2">
        @livewire('constructor-project')
    </div>
@endsection
